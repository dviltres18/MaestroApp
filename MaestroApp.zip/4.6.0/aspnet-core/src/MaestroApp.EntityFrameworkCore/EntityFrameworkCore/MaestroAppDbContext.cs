﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using MaestroApp.Authorization.Roles;
using MaestroApp.Authorization.Users;
using MaestroApp.MultiTenancy;

namespace MaestroApp.EntityFrameworkCore
{
    public class MaestroAppDbContext : AbpZeroDbContext<Tenant, Role, User, MaestroAppDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public MaestroAppDbContext(DbContextOptions<MaestroAppDbContext> options)
            : base(options)
        {
        }
    }
}
