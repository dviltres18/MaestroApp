﻿namespace MaestroApp
{
    public class MaestroAppConsts
    {
        public const string LocalizationSourceName = "MaestroApp";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
