﻿using Abp.MultiTenancy;
using MaestroApp.Authorization.Users;

namespace MaestroApp.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
